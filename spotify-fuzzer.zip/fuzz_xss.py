import requests
from utils.payload_generator import xss_payloads

URL = "https://www.open.spotify.com/search"

def fuzz():
    print("[*] Starting XSS fuzz on 'query' parameter...")
    for payload in xss_payloads:
        params = {"query": payload}
        r = requests.get(URL, params=params)
        if payload in r.text:
            print(f"[+] Potential XSS with payload: {payload}")
            with open("reports/xss_hits.txt", "a") as f:
                f.write(f"{payload}\n")

if __name__ == "__main__":
    fuzz()
