# Spotify Web Fuzzer – Bug Bounty PoC

This repository contains custom fuzzers built for identifying web application vulnerabilities in Spotify services. It includes fuzzers for detecting SQL Injection and Cross-Site Scripting (XSS), both of which were tested on Spotify’s public endpoints for responsible disclosure.

## Features
- **Targeted SQL Injection detection** on vulnerable parameters.
- **Automated XSS payload testing** for stored and reflected vulnerabilities.
- Payload rotation and custom mutation engine.
- PoC reports prepared for HackerOne submission.

## Usage

```bash
# Install dependencies
pip install -r requirements.txt

# Run the SQLi fuzzer
python fuzz_sql_injection.py

# Run the XSS fuzzer
python fuzz_xss.py
```

## Structure
- `fuzz_sql_injection.py`: Fuzzer targeting `id` parameter on spotify.com
- `fuzz_xss.py`: Fuzzer for the `query` parameter on open.spotify.com
- `utils/payload_generator.py`: Shared logic for payload rotation and encoding
- `reports/`: HackerOne-style vulnerability reports

## Disclaimer
This tool is intended for educational and responsible disclosure purposes only. Always test on authorized targets.

## License
MIT
