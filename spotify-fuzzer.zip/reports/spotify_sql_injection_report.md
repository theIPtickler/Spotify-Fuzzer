# Vulnerability Report – Spotify.com

**Vulnerability:** SQL Injection  
**Target URL:** https://www.spotify.com/vulnerablepage?id=1  
**Type:** High Severity

## Description
SQL Injection vulnerability identified in the `id` parameter. Malicious input results in SQL syntax errors, indicating lack of sanitization.

## Steps to Reproduce
1. Navigate to: `https://www.spotify.com/vulnerablepage?id=1' OR '1'='1`
2. Observe SQL error in response: `"You have an error in your SQL syntax"`

## Impact
An attacker could dump database content, modify backend queries, or escalate access.

## Recommendation
Implement parameterized queries and input validation on all user-controlled input.
