# Vulnerability Report – open.spotify.com

**Vulnerability:** Stored Cross-Site Scripting (XSS)  
**Target URL:** https://www.open.spotify.com/search?query=<script>alert(1)</script>  
**Type:** Medium Severity

## Description
Stored XSS vulnerability identified in the `query` parameter. User-supplied JavaScript executes upon loading.

## Steps to Reproduce
1. Visit: `https://www.open.spotify.com/search?query=<script>alert(1)</script>`
2. XSS payload triggers a browser alert

## Impact
Allows execution of arbitrary JavaScript in victim’s browser, potentially leading to session hijacking or phishing.

## Recommendation
Escape output and validate input server-side to prevent code injection.
